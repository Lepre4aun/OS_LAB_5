﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 3000; i++)
                Console.WriteLine("Третье приложение работает. " + i.ToString());
        }
    }
}
